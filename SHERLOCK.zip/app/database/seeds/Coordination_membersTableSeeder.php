<?php

class Coordination_membersTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('coordination_members')->truncate();

		$coordination_members = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('coordination_members')->insert($coordination_members);
	}

}
