<?php

class Disposition_anexxesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('disposition_anexxes')->truncate();

		$disposition_anexxes = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('disposition_anexxes')->insert($disposition_anexxes);
	}

}
