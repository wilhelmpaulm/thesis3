<?php

class ComplaintsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('complaints')->truncate();

		$complaints = array(

//			["id" => , "date_commited" =>"", "date_reported" =>"", "narration" =>"", "agency_reported" =>"", "agency_report_details" =>"", "agency_report_status" =>"", "court_action_details" =>"", "considerations" =>"", "img_signature" =>"", "img_right_thumb" =>""],

		);

		// Uncomment the below to run the seeder
		// DB::table('complaints')->insert($complaints);
	}

}
