<?php

class Case_formsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('case_forms')->truncate();

		$case_forms = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('case_forms')->insert($case_forms);
	}

}
