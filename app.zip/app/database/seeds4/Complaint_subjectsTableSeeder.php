<?php

class Complaint_subjectsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('complaint_subjects')->truncate();

		$complaint_subjects = array(

//			["id" => , "complaint_id" =>, "client_id" =>],

		);

		// Uncomment the below to run the seeder
		// DB::table('complaint_subjects')->insert($complaint_subjects);
	}

}
